"""
Ingest KICD curriculum design JSON (extracted via Docling) into ChromaDB.

This script assumes your Docling JSON exports live in a folder, and that
headings in the source PDFs follow the standard KICD pattern:

    Grade X <Subject> Curriculum Design
        Strand: <strand name>
            Sub-strand: <sub-strand name>
                Specific Learning Outcomes: ...
                Suggested Learning Experiences: ...
                Key Inquiry Question(s): ...
                Core Competencies: ...
                Pertinent and Contemporary Issues (PCIs): ...
                Values: ...
                Suggested Assessment Methods: ...

Because heading text varies slightly across KICD documents (capitalization,
"Sub Strand" vs "Sub-strand", etc.), this script uses lenient matching.
If your documents deviate significantly, adjust HEADING PATTERNS below --
this is the one part of the pipeline worth hand-checking against your
actual JSON before trusting the output.

Usage:
    1. Put your Docling JSON files (e.g. grade4_agriculture_design.json)
       in the "docling_json/" folder next to this script.
    2. Set GEMINI_API_KEY as an environment variable.
    3. python ingest.py
"""

import json
import os
import re
import sys
from pathlib import Path

import chromadb
from chromadb.utils import embedding_functions

DOCLING_JSON_DIR = Path("docling_json")
CHROMA_DB_PATH = "./kicd_chroma_db"
COLLECTION_NAME = "kicd_curriculum"

# Lenient regex patterns to identify each field within a sub-strand block.
# Adjust these against your actual extracted text if matches come up empty.
HEADING_PATTERNS = {
    "strand": re.compile(r"^\s*strand\s*[:\-]?\s*(.+)", re.IGNORECASE),
    "sub_strand": re.compile(r"^\s*sub[\s\-]?strand\s*[:\-]?\s*(.+)", re.IGNORECASE),
    "learning_outcomes": re.compile(r"specific\s+learning\s+outcomes?", re.IGNORECASE),
    "learning_experiences": re.compile(r"suggested\s+learning\s+experiences?", re.IGNORECASE),
    "key_inquiry": re.compile(r"key\s+inquiry\s+questions?", re.IGNORECASE),
    "core_competencies": re.compile(r"core\s+competenc(y|ies)", re.IGNORECASE),
    "pcis": re.compile(r"pertinent\s+and\s+contemporary\s+issues|PCIs?", re.IGNORECASE),
    "values": re.compile(r"^\s*values?\s*[:\-]?", re.IGNORECASE),
    "assessment": re.compile(r"suggested\s+assessment\s+methods?", re.IGNORECASE),
}


def extract_grade_subject_from_filename(filename: str) -> tuple[str, str]:
    """Best-effort parse of grade/subject from a filename like
    'grade4_agriculture_design.json'. Falls back to 'Unknown' -- fix the
    metadata manually afterward if this guesses wrong for your naming scheme."""
    stem = Path(filename).stem.lower()
    grade_match = re.search(r"grade\s*(\d+)|g(\d+)", stem)
    grade = f"Grade {grade_match.group(1) or grade_match.group(2)}" if grade_match else "Unknown"
    subject_match = re.sub(r"(grade\s*\d+|g\d+|design|curriculum)", "", stem)
    subject = subject_match.strip("_- ").replace("_", " ").title() or "Unknown"
    return grade, subject


def iter_text_items(doc_dict: dict):
    """Yield (text, page_no) for every text-bearing element in a
    DoclingDocument export_to_dict() structure, in reading order."""
    for item in doc_dict.get("texts", []):
        text = item.get("text", "").strip()
        if not text:
            continue
        page_no = None
        prov = item.get("prov") or []
        if prov:
            page_no = prov[0].get("page_no")
        yield text, page_no


def group_into_substrand_chunks(doc_dict: dict, grade: str, subject: str, source_file: str) -> list[dict]:
    """Walk the document's text items and group everything between one
    'Sub-strand:' heading and the next into a single chunk, carrying the
    most recent 'Strand:' heading as metadata."""
    chunks = []
    current_strand = ""
    current_sub_strand = None
    current_lines: list[str] = []
    current_page = None
    current_pcis: list[str] = []

    def flush():
        if current_sub_strand and current_lines:
            full_text = "\n".join(current_lines)
            pci_matches = HEADING_PATTERNS["pcis"].search(full_text)
            pcis = current_pcis or (["See text"] if pci_matches else [])
            chunk_id = re.sub(
                r"[^a-z0-9]+", "_",
                f"{grade}_{subject}_{current_sub_strand}".lower()
            ).strip("_")
            chunks.append({
                "id": chunk_id,
                "text": f"Strand: {current_strand}\nSub-strand: {current_sub_strand}\n\n{full_text}",
                "metadata": {
                    "grade": grade,
                    "subject": subject,
                    "strand": current_strand,
                    "sub_strand": current_sub_strand,
                    "pcis": ", ".join(pcis) if pcis else "",
                    "source_page": current_page or 0,
                    "source_file": source_file,
                }
            })

    for text, page_no in iter_text_items(doc_dict):
        strand_m = HEADING_PATTERNS["strand"].match(text)
        substrand_m = HEADING_PATTERNS["sub_strand"].match(text)

        if strand_m and not substrand_m:
            current_strand = strand_m.group(1).strip()
            continue

        if substrand_m:
            flush()  # save the previous sub-strand block before starting a new one
            current_sub_strand = substrand_m.group(1).strip()
            current_lines = []
            current_page = page_no
            current_pcis = []
            continue

        if current_sub_strand is not None:
            current_lines.append(text)
            if HEADING_PATTERNS["pcis"].search(text):
                current_pcis.append(text)

    flush()  # save the final block
    return chunks


def main():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Set the GEMINI_API_KEY environment variable first.")
        sys.exit(1)

    if not DOCLING_JSON_DIR.exists():
        print(f"'{DOCLING_JSON_DIR}' not found. Put your Docling JSON exports there.")
        sys.exit(1)

    json_files = sorted(DOCLING_JSON_DIR.glob("*.json"))
    if not json_files:
        print(f"No JSON files found in '{DOCLING_JSON_DIR}'.")
        sys.exit(0)

    all_chunks = []
    for jf in json_files:
        grade, subject = extract_grade_subject_from_filename(jf.name)
        with open(jf, encoding="utf-8") as f:
            doc_dict = json.load(f)
        chunks = group_into_substrand_chunks(doc_dict, grade, subject, jf.name)
        print(f"{jf.name}: parsed as {grade} / {subject} -> {len(chunks)} sub-strand chunk(s)")
        if not chunks:
            print(f"  !! No sub-strand headings matched in {jf.name}. "
                  f"Check HEADING_PATTERNS against this file's actual text.")
        all_chunks.extend(chunks)

    if not all_chunks:
        print("\nNo chunks produced across any file. Nothing to ingest.")
        sys.exit(1)

    print(f"\nTotal chunks to ingest: {len(all_chunks)}")

    client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
    gemini_ef = embedding_functions.GoogleGenerativeAiEmbeddingFunction(
        api_key=api_key,
        model_name="models/text-embedding-004",
    )
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=gemini_ef,
    )

    # Upsert in batches to stay well under any single-request size limits
    batch_size = 50
    for i in range(0, len(all_chunks), batch_size):
        batch = all_chunks[i:i + batch_size]
        collection.upsert(
            ids=[c["id"] for c in batch],
            documents=[c["text"] for c in batch],
            metadatas=[c["metadata"] for c in batch],
        )
        print(f"  Upserted {i + len(batch)}/{len(all_chunks)}")

    print(f"\nDone. Collection '{COLLECTION_NAME}' now has {collection.count()} chunk(s) "
          f"stored at {CHROMA_DB_PATH}")


if __name__ == "__main__":
    main()
